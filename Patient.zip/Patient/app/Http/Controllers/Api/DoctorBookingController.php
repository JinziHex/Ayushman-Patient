<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Mst_Branch;
use App\Models\Mst_TimeSlot;
use App\Models\Mst_User;
use App\Models\Trn_Staff_Leave;
use App\Models\Mst_Doctor;
use App\Models\Trn_Consultation_Booking;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;

class DoctorBookingController extends Controller
{
    public function getBranches(){
        $branches = Mst_Branch::where('is_active', 1)->get(['id', 'branch_name'])->toArray();

        $data['status'] = 1;
        $data['message'] = "Data fetched.";
        $data['data'] = $branches;
        return response($data);
    }

    public function doctorsList(Request $request){
        $data=array();
        try{
            $validator = Validator::make(
                $request->all(),
                [
                    'branch_id' => ['required'],
                    'booking_date' => ['required'],
                ],
                [
                    'branch_id.required' => 'Branch required',
                    'booking_date.required' => 'Booking date required',
                ]
            );

            if (!$validator->fails()) 
            {
                if (isset($request->booking_date) && !empty($request->booking_date)) {

                    $doctorONLeave = Trn_Staff_Leave::where('leave_date', $request->booking_date)->pluck('user_id')->toArray();

                    $queries = Mst_User::join('mst_branches', 'mst_users.branch_id', '=', 'mst_branches.id')
                                ->join('mst__doctors', 'mst_users.id', '=', 'mst__doctors.user_id')
                                ->join('mst__designations', 'mst__doctors.designation_id', '=', 'mst__designations.id')
                                ->select('mst_users.id as doctor_id', 'mst_users.username as name', 'mst_branches.branch_name as branch_name', 'mst__designations.designation as designation')
                                ->where('mst_users.user_type_id', 3)
                                ->where('mst_users.branch_id', $request->branch_id)
                                ->whereNotIn('mst_users.id', $doctorONLeave);

                    if(isset($request->search_doctor_name)){
                        $queries = $queries->where('mst_users.username', 'like', '%' . $request->search_doctor_name . '%');
                    }

                    if(isset($request->search_branch_name)){
                        $queries = $queries->where('mst_branches.branch_name', 'like', '%' . $request->search_branch_name . '%');
                    }

                    if(isset($request->search_designation_name)){
                        $queries = $queries->where('mst__designations.designation', 'like', '%' . $request->search_designation_name . '%');
                    }
            
                    $doctorsList = $queries->get();

                    $data['status'] = 1;
                    $data['message'] = "Data fetched";
                    $data['data'] = $doctorsList;
                    return response($data);
                }else{
                    $data['status'] = 0;
                    $data['message'] = "Please select branch and date";
                    return response($data);
                }
                
            }
            else
            {
                $data['status'] = 0;
                $data['errors'] = $validator->errors();
                $data['message'] = "Validation errors";
                return response($data);
            }
        } 

        catch (\Exception $e) {
            $response = ['status' => '0', 'message' => $e->getMessage()];
            return response($response);
        
        } catch (\Throwable $e) {
            $response = ['status' => '0', 'message' => $e->getMessage()];
            return response($response);
        }
    }

    public function doctorsDetails(Request $request){
        $data=array();
        try{
            $validator = Validator::make(
                $request->all(),
                [
                    'doctor_id' => ['required'],
                ],
                [
                    'doctor_id.required' => 'Doctor required',
                ]
            );
            if (!$validator->fails()) 
            {
                if(isset($request->doctor_id)){
                    $doctorDetails = Mst_User::join('mst_branches', 'mst_users.branch_id', '=', 'mst_branches.id')
                    ->join('mst__doctors', 'mst_users.id', '=', 'mst__doctors.user_id')
                    ->join('mst__designations', 'mst__doctors.designation_id', '=', 'mst__designations.id')
                    ->join('trn_user_profiles', 'mst_users.id', '=', 'trn_user_profiles.user_id')
                    ->select('mst_users.id as doctor_id', 'mst_users.username as name', 'mst_branches.branch_name as branch_name', 'mst__doctors.qualification', 'trn_user_profiles.address', 'trn_user_profiles.profile_image', 'mst__designations.designation as designation')
                    ->where('mst_users.user_type_id', 3)
                    ->where('mst_users.id', $request->doctor_id)
                    ->first();

                    if ($doctorDetails) {
                        $doctorDetails->profile_image = 'http://127.0.0.1:8000/public/assets/uploads/doctor_profile/' . $doctorDetails->profile_image;
                        $data['status'] = 1;
                        $data['message'] = "Data fetched";
                        $data['data'] = $doctorDetails;
                    } else {
                        $data['status'] = 0;
                        $data['message'] = "No doctor found";
                    }

                    return response($data);

                }else{
                    $data['status'] = 0;
                    $data['message'] = "Please select a doctor";
                    return response($data);
                }
            }
            else{
                $data['status'] = 0;
                $data['errors'] = $validator->errors();
                $data['message'] = "Validation errors";
                return response($data);
            }
        }
        catch (\Exception $e) {
            $response = ['status' => '0', 'message' => $e->getMessage()];
            return response($response);
        
        } catch (\Throwable $e) {
            $response = ['status' => '0', 'message' => $e->getMessage()];
            return response($response);
        }
    }
}
